package phonebook

class Entry {
	String phoneName;
	int  phoneNumber;
	Entry(String name, int number) {
		phoneName = name;
		phoneNumber = number;
	}
}
